const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: 'duusv7nak',
  api_key: '433967572837534',
  api_secret: 'LiTmpJmJCIdTVNYBvJWlVj-32xw',
});

module.export = cloudinary;
